# Bluetooth
Conexion arduino con android

Seguime en http://cursoandroidstudio.blogspot.com.ar/ y en http://cursoarduinomega.blogspot.com.ar/

La idea de este tutorial es ver como funciona la conexion bluetooth de arduino con android y viceversa.
Espero que le sea de ayuda

